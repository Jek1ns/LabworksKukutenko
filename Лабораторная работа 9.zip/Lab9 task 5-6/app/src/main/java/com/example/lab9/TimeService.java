package com.example.lab9;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class TimeService extends Service {

    // Та самая переменная, куда сервис будет писать время каждую секунду
    public static String currentTime = "Сервис еще не обновил время";

    private Timer timer;
    private NotificationManager notificationManager;
    private static final String CHANNEL_ID = "TimeChannel";

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel(); // Для современных Android-версий
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (timer == null) {
            timer = new Timer();
            // Запускаем задачу, которая будет повторяться каждую секунду (1000 мс)
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    // Форматируем время в HH:mm:ss
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
                    String formattedTime = sdf.format(new Date());

                    // Записываем в нашу переменную
                    currentTime = formattedTime;

                    // Если секунды равны 00, показываем уведомление
                    if (formattedTime.endsWith(":00")) {
                        showNotification(formattedTime);
                    }
                }
            }, 0, 1000);
        }

        return START_STICKY;
    }

    private void showNotification(String timeText) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Новая минута!")
                .setContentText(timeText)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Уведомления времени",
                    NotificationManager.IMPORTANCE_HIGH
            );
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        if (timer != null) {
            timer.cancel();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}