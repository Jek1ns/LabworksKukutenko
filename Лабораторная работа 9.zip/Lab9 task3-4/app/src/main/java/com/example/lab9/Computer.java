package com.example.lab9;

import java.io.Serializable;

public class Computer implements Serializable {
    private String title;
    private double price;

    public Computer(String title, double price) {
        this.title = title;
        this.price = price;
    }


    @Override
    public String toString() {
        return title + " (" + price + " руб.)";
    }
}