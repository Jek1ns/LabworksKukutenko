package com.example.lab9;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {

    private ListView lvComputers;
    private Button btnBack;

    // СТАТИЧЕСКИЙ список: он сохраняет данные в памяти, пока приложение работает
    private static final ArrayList<Computer> computerList = new ArrayList<>();
    private ArrayAdapter<Computer> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        lvComputers = findViewById(R.id.lv_computers);
        btnBack = findViewById(R.id.btn_back);

        // Настраиваем адаптер для отображения списка
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, computerList);
        lvComputers.setAdapter(adapter);

        // Проверяем, пришел ли новый компьютер из MainActivity
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("computer_data")) {
            Computer newComputer = (Computer) intent.getSerializableExtra("computer_data");
            if (newComputer != null) {
                computerList.add(newComputer); // Добавляем в общий список
                adapter.notifyDataSetChanged(); // Обновляем экран
            }
            // Удаляем extra, чтобы при повороте экрана объект не добавился еще раз
            intent.removeExtra("computer_data");
        }

        // Кнопка Назад просто закрывает текущий экран
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}