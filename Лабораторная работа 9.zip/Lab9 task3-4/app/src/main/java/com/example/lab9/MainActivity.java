package com.example.lab9;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etTitle, etPrice;
    private Button btnAdd;
    private TextView tvClickMe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvClickMe = findViewById(R.id.tv_click_me);
        etTitle = findViewById(R.id.et_title);
        etPrice = findViewById(R.id.et_price);
        btnAdd = findViewById(R.id.btn_add);

        // Переход по клику на текст через Intent-фильтр
        tvClickMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Вызываем через Action, прописанный в Манифесте
                Intent intent = new Intent("com.example.lab9.VIEW_SECOND");
                startActivity(intent);
            }
        });

        // Создание объекта и отправка
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = etTitle.getText().toString().trim();
                String priceStr = etPrice.getText().toString().trim();

                if (title.isEmpty() || priceStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Заполните все поля!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double price = Double.parseDouble(priceStr);

                // Создаем объект
                Computer computer = new Computer(title, price);

                // Отправляем на второй экран (тоже используем Intent-фильтр)
                Intent intent = new Intent("com.example.lab9.VIEW_SECOND");
                intent.putExtra("computer_data", computer);
                startActivity(intent);

                // Очищаем поля ввода для следующего раза
                etTitle.setText("");
                etPrice.setText("");
            }
        });
    }
}