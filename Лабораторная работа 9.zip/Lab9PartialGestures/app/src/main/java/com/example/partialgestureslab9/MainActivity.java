package com.example.partialgestureslab9;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private GestureDetectorCompat mDetector;
    private TextView tvOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Убедись, что тут указан твой XML файл

        tvOut = findViewById(R.id.textView1);

        // В конструктор передаем наш кастомный класс-слушатель MyGestListener
        mDetector = new GestureDetectorCompat(this, new MyGestListener());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // Передаем сенсорные события в детектор
        if (this.mDetector.onTouchEvent(event)) {
            return true;
        }
        return super.onTouchEvent(event);
    }

    // --- ВНУТРЕННИЙ КЛАСС ---
    // Наследуемся от SimpleOnGestureListener, чтобы не писать все методы подряд
    class MyGestListener extends GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onFling(MotionEvent event1, MotionEvent event2, float velocityX, float velocityY) {
            tvOut.setText("onFling: " + event1.toString()+event2.toString());
            return true;
        }
    }
}