package com.example.lab9;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.app.Activity;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView tvRestartCount;
    private int restartCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvRestartCount = findViewById(R.id.tvRestartCount);
        updateRestartCount();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        restartCount++;
        updateRestartCount();
    }

    private void updateRestartCount() {
        tvRestartCount.setText("Обновлений: " + restartCount);
    }
}
