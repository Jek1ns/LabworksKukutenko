package com.example.lab9;

import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.Prediction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity<ErrorDialog> extends AppCompatActivity implements GestureOverlayView.OnGesturePerformedListener {

    private EditText editNumber;
    private Button btnCheck;
    private Button btnBack;

    // Переменные для работы с жестами
    private GestureLibrary gLib;
    private GestureOverlayView gestures;

    // Загаданное число
    private int targetNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editNumber = findViewById(R.id.edit_number);
        btnCheck = findViewById(R.id.btn_check);
        btnBack = findViewById(R.id.btn_back);

        // Генерация случайного числа от 1 до 10
        generateNewTargetNumber();

        // Загрузка библиотеки жестов из res/raw/gestures
        gLib = GestureLibraries.fromRawResource(this, R.raw.gestures);
        if (!gLib.load()) {
            Toast.makeText(this, "Файл жестов не найден!", Toast.LENGTH_LONG).show();
            finish(); // Выход, если жесты не загрузились
        }

        // Подключение слушателя к слою с жестами
        gestures = findViewById(R.id.gestureOverlayView);
        gestures.addOnGesturePerformedListener(this);

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkGuessedNumber();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Изменил логику на очистку поля, так как это теперь главная активность
                editNumber.setText("");
            }
        });
    }

    // Обработка нарисованных жестов
    @Override
    public void onGesturePerformed(GestureOverlayView overlay, Gesture gesture) {
        ArrayList<Prediction> predictions = gLib.recognize(gesture);

        if (predictions.size() > 0) {
            Prediction prediction = predictions.get(0);

            // Проверяем точность совпадения
            if (prediction.score > 1.0) {
                String gestureName = prediction.name;

                if (gestureName.equalsIgnoreCase("S")) {
                    // Жест "S" для остановки ввода и проверки результата
                    btnCheck.performClick();
                } else if (gestureName.matches("[0-9]")) {
                    // Дописываем распознанную цифру в поле
                    editNumber.append(gestureName);
                } else {
                    Toast.makeText(this, "Неизвестный жест: " + gestureName, Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    // Твоя логика проверки числа с добавлением сравнения
    private void checkGuessedNumber() {
        String input = editNumber.getText().toString();

        if (input.isEmpty()) {
            Toast.makeText(this, "Сначала нарисуйте число!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int number = Integer.parseInt(input);

            if (number >= 1 && number <= 10) {
                // Сравниваем с загаданным числом
                if (number == targetNumber) {
                    Toast.makeText(this, "Победа! Вы угадали число " + targetNumber, Toast.LENGTH_LONG).show();
                    editNumber.setText("");
                    generateNewTargetNumber(); // Загадываем новое число
                } else if (number > targetNumber) {
                    Toast.makeText(this, "Загаданное число меньше!", Toast.LENGTH_SHORT).show();
                    editNumber.setText("");
                } else {
                    Toast.makeText(this, "Загаданное число больше!", Toast.LENGTH_SHORT).show();
                    editNumber.setText("");
                }
            } else {
                ErrorDialog dialog = new ErrorDialog("Число должно быть от 1 до 10");
                dialog.wait(getSupportFragmentManager(), "error_dialog");
                editNumber.setText("");
            }
        } catch (NumberFormatException e) {
            ErrorDialog dialog = new ErrorDialog("Должно быть введено только число, причём строго от 1 до 10");
            dialog.wait(getSupportFragmentManager(), "error_dialog");
            editNumber.setText("");
        }
    }

    private void generateNewTargetNumber() {
        targetNumber = new Random().nextInt(10) + 1;
    }
}