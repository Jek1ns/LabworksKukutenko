package com.example.lab1

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        val backButton = findViewById<Button>(R.id.btn_back_third)
        backButton.setOnClickListener {
            finish()
        }
    }
}