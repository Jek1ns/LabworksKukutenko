package com.example.lab1
import android.os.Bundle
import android.widget.Button
import android.content.Intent
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
class SecondActivity  : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val resultTextView = findViewById<TextView>(R.id.result_text)
        val surnameView = findViewById<TextView>(R.id.surname)
        val backButton = findViewById<Button>(R.id.btn_back)
        val nextButton = findViewById<Button>(R.id.btn_to_third)
        // 1. Получаем и отображаем Фамилию из ресурсов
        val surname = intent.getStringExtra("PARAM_SURNAME")
        surnameView.text = getString(R.string.result_format, surname)
        val resultMessage = intent.getStringExtra("AUTH_RESULT")
        resultTextView.text = resultMessage

        // Кнопка Назад
        backButton.setOnClickListener { finish() }

        // Переход на 3-ю Activity
        nextButton.setOnClickListener {
            val intent = Intent(this, ThirdActivity::class.java)
            startActivity(intent)
        }
    }
}