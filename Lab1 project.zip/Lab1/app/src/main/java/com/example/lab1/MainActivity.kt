package com.example.lab1

import android.R.id.message
import android.content.Intent // Нужно добавить
import android.os.Bundle
import android.widget.Button   // Нужно добавить
import android.widget.EditText // Нужно добавить
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val emailInput = findViewById<EditText>(R.id.input_email)
        val passwordInput = findViewById<EditText>(R.id.input_password)
        val sendButton = findViewById<Button>(R.id.btn_login)

        sendButton.setOnClickListener {
            val email = emailInput.text.toString()
            val password = passwordInput.text.toString()


            if (email == "admin@admin.ru" && password == "123") {
                val intent = Intent(this@MainActivity, SecondActivity::class.java)

                // Берем фамилию из ресурсов
                val surname = getString(R.string.my_surname)
                val message = getString(R.string.auth_success)
                    // кладем фамилию в intent
                intent.putExtra("PARAM_SURNAME", surname)
                intent.putExtra("AUTH_RESULT", message)
                startActivity(intent)
            } else {

                emailInput.error = getString(R.string.auth_error)
            }


        }
    }
}