package com.kukutenko.feedthecat;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    // Константы для ключей, чтобы не ошибиться в опечатках
    private static final String PREFS_FILE = "FullnessPrefs";
    private static final String KEY_COUNT = "fullness_level";

    TextView text;
    Button btn;
    int count = 0;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (TextView) findViewById(R.id.textView);
        btn = (Button) findViewById(R.id.button);

        // 1. Инициализируем SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE);

        // 2. Восстановление значения при запуске
        loadCount();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                count++;
                text.setText(String.valueOf(count));

                // 3. Сохраняем новое значение при каждом клике
                saveCount();
            }
        });
    }

    // Метод для сохранения данных
    private void saveCount() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(KEY_COUNT, count);
        editor.apply(); // apply() делает это в фоновом режиме, не тормозя UI
    }

    // Метод для загрузки данных
    private void loadCount() {
        // Читаем значение. Если его еще нет в памяти, вернется 0 (второй аргумент)
        count = sharedPreferences.getInt(KEY_COUNT, 0);
        text.setText(String.valueOf(count));
    }
}